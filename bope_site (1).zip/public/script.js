document.addEventListener("DOMContentLoaded", () => {
  const parceriaForm = document.getElementById("parceria-form");
  const candidatoForm = document.getElementById("candidato-form");

  parceriaForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(parceriaForm).entries());
    const response = await fetch("/api/parcerias", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    alert(await response.text());
    parceriaForm.reset();
  });

  candidatoForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(candidatoForm);
    const response = await fetch("/api/candidatos", {
      method: "POST",
      body: formData,
    });
    alert(await response.text());
    candidatoForm.reset();
  });
});