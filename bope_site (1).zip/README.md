# BOPE - Bolsa de Profissionais da Edbiz

## Como configurar
1. Criar uma Google Sheet com abas "Parcerias" e "Candidatos".
2. Ativar API Google Sheets e criar credenciais de serviço.
3. Fazer download do `credentials.json` e colocar na pasta `server/`.
4. Colocar o ID da planilha em `.env` (baseado no `.env.example`).
5. Instalar dependências:
   ```bash
   cd server
   npm install
   npm start
   ```
6. O site estará disponível em http://localhost:3000
