import express from 'express';
import multer from 'multer';
import { google } from 'googleapis';
import fs from 'fs';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
const upload = multer({ dest: 'uploads/' });

app.use(express.json());
app.use(express.static('public'));

async function authSheets() {
  const auth = new google.auth.GoogleAuth({
    keyFile: 'credentials.json',
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });
  return google.sheets({ version: 'v4', auth: await auth.getClient() });
}

app.post('/api/parcerias', async (req, res) => {
  try {
    const sheets = await authSheets();
    await sheets.spreadsheets.values.append({
      spreadsheetId: process.env.SHEET_ID,
      range: 'Parcerias!A:D',
      valueInputOption: 'RAW',
      requestBody: { values: [[req.body.empresa, req.body.email, req.body.telefone, req.body.mensagem]] },
    });
    res.send("Parceria registada com sucesso!");
  } catch (error) {
    res.status(500).send("Erro ao registar parceria.");
  }
});

app.post('/api/candidatos', upload.single('cvUpload'), async (req, res) => {
  try {
    const sheets = await authSheets();
    const data = req.body;
    await sheets.spreadsheets.values.append({
      spreadsheetId: process.env.SHEET_ID,
      range: 'Candidatos!A:E',
      valueInputOption: 'RAW',
      requestBody: { values: [[data.nome, data.area, data.email, data.telefone, data.cvLink || (req.file ? req.file.path : "")]] },
    });
    res.send("Candidato registado com sucesso!");
  } catch (error) {
    res.status(500).send("Erro ao registar candidato.");
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor a correr na porta ${PORT}`));